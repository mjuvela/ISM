from numpy import *
from numpy.random import randn

# allocate the cube containing seven parameters for each cell
N       = 64
C       = ones((N, N, N, 7), float32)   # start with values 1.0 for all parameters

# calculate cell distances from the centre
k, j, i = indices((N,N,N), float32)
c       = 0.5*(N-1.0)                 # coordinate value at the centre
i, j, k = (i-c)/c, (j-c)/c, (k-c)/c   # coordinates in the [-1,1] range
r       = sqrt(i*i+j*j+k*k)           # distance from the centre

# Set the values in the cube
C[:,:,:,0]   = exp(-3.0**r*r)         # density values, 3D Gaussian
C[:,:,:,1]  *= 15.0                   # Tkin=15 K in every cell
C[:,:,:,2]  *=  1.0                   # leave microturbulence at 1 km/s
C[:,:,:,3]   = randn(N,N,N)           # macroscopic velocities as 
C[:,:,:,4]   = randn(N,N,N)           #   normal-distributed random numbers
C[:,:,:,5]   = randn(N,N,N)           #   ~N(0,1) for all three axes
C[:,:,:,6]   = 1.0                    # abundance values will be scaled later

# Write the cloud file - Cartesian-grid format
fp = open('my.cloud', 'wb')
asarray([N, N, N], int32).tofile(fp)
C.tofile(fp)
fp.close()

# Write the cloud file - Octree format
fp = open('my.octree', 'wb')
asarray([N, N, N, 1, N*N*N], int32).tofile(fp)
for ifield in range(7):
    asarray([N*N*N,], int32).tofile(fp)
    C[:,:,:,ifield].tofile(fp)
fp.close()
