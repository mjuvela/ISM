
Make a 3d model cloud ("tmp.cloud") by running 
> python make_cloud.py

Run SOC using the ini file tmp.ini
> ASOC.py tmp.ini

Plot the results
> python plot_T.py


The zip contains the other files needed for the SOC run:
- tmp.dust, tmp.dsc = dust optical properties and scattering functions
- bg_intensity.bin
- to assist the plotting, also freq.dat = list of frequencies
  (the same frequency grid as in tmp.dust and bg_intensity.bin)

