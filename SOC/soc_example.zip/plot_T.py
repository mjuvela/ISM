from matplotlib.pylab import *

# We assume that there is a list of frequencies in freq.dat that corresponds to the
# SOC run.

freq      = loadtxt('freq.dat')
nfreq     = len(freq)

figure(1, figsize=(8,2.8))

# Read the map file
fp        = open('map_dir_00.bin', 'rb')
dims      = fromfile(fp, int32, 2)    #  map dimensions in pixels
S         = 1.0e-6*fromfile(fp, float32).reshape(nfreq, dims[0], dims[1]) # convert to MJy/sr
fp.close()
# Choose frequency closest to 250um
ifreq     = argmin(abs(freq-2.9979e8/250.0e-6))
# First frame = 250um surface brightness
ax = subplot(121)
imshow(S[ifreq,:,:])
title("Surface brightness")
colorbar()
text(1.34, 0.5, r'$S_{\nu} \/ \/ \rm (MJy \/ sr^{-1})$', transform=ax.transAxes, va='center', rotation=90)

# Read the Tdust file... which is now also just N*N*N cells
fp       = open('tmp.T', 'rb') 
NX, NY, NZ, LEVELS, CELLS, CELLS_LEVEL_1 = fromfile(fp, int32, 6)
# The rest is simply the cube
T        = fromfile(fp, float32).reshape(NZ, NY, NX)
# Plot a cross section through the cloud centre
ax = subplot(122)
imshow(T[NX//2, :, :])
title("Dust temperature")
colorbar()
text(1.34, 0.5, r'$T_{\rm dust} \/ \/ \rm (K)$', transform=ax.transAxes, va='center', rotation=90)

show()




